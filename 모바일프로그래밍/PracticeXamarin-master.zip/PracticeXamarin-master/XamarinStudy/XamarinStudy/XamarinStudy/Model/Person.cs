﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XamarinStudy.Model
{
    public class Person
    {
        public string Name { get; set; }
        public String Address { get; set; }
        public String Phone { get; set; }
        public String Image { get; set; }
    }
}
